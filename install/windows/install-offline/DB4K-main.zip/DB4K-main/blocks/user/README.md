# User Blocks

User created blocks will be saved in this directory.

### This feature has not yet been implemented.
